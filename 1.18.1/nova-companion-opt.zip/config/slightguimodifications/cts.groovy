mainMenu {
    enabled = true // Set to true to enable this module
    label {
        position {
            x { it - 2 }
            y { it - 20 }
        }
        text = literal("Nova Companion 2.0.1")
        align = "right"
        color = 0xFFFFFF
        hoveredColor = 0x6DFFFB
        shadow = true
        onClicked = url("https://discord.gg/m52kfmbqAm")
    }
}